import java.util.*;
public class eval12 {
    public static void main (String[]args){
        Scanner sc = new Scanner(System.in);

        int alto=0, ancho=0;
        char ast = '*', igual = '=';
        String nombre = "";

        while (ancho<4){
            System.out.println("Introduzca anchura del cuadro (mínimo 4): ");
            ancho = sc.nextInt();
        }
        while (alto<4){
            System.out.println("Introduzca altura del cuadro (mínimo 4): ");
            alto = sc.nextInt();
        }
        sc.nextLine();
        System.out.println("Introduzca el nombre del cuadro: ");
        nombre = sc.nextLine();

        System.out.println(nombre);

        for (int i=0; i<alto/2; i++){

            for(int j=0; j<ancho; j++){
                System.out.print(ast);
                if (j==(ancho-1)){
                    System.out.println("\n");
                }
            }
            for(int k=0; k<ancho; k++){
                System.out.print(igual);
                if (k==(ancho-1)){
                    System.out.println("\n");
                }
            }
        }


    }
}
