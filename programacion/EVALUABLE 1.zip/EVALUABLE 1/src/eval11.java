import java.util.*;
public class eval11 {
    public static void main (String[]args){
        Scanner sc = new Scanner (System.in);

        int num1=0, num2=0, num3=0, num4=0;
        int intentos=0;

        System.out.println("Bienvenido al ejercicio de la caja fuerte!");

            for (int i=1; i<15; i++){
                System.out.println("Este es tu intento número "+i);
                System.out.println("Introduca digito 1:");
                num1 = sc.nextInt();
                System.out.println("Introduca digito 2:");
                num2 = sc.nextInt();
                System.out.println("Introduca digito 3:");
                num3 = sc.nextInt();
                System.out.println("Introduca digito 4:");
                num4 = sc.nextInt();

                if ((num1==2)&&(num2==3)&&(num3==2)&&(num4==3)){
                    System.out.println("Felicidades! La clave era "+num1+num2+num3+num4);
                    break;
                }else{
                    System.out.println("Mala suerte, sigue intentándolo!");
                    if (num1==2){
                        System.out.println("Aunque el primer digito lo has acertado, es el "+num1+"!");
                    }
                    if (num2==3){
                        System.out.println("Aunque el segundo digito lo has acertado, es el "+num2+"!");
                    }
                    if (num3==2){
                        System.out.println("Aunque el tercer digito lo has acertado, es el "+num3+"!");
                    }
                    if (num4==3){
                        System.out.println("Aunque el cuarto digito lo has acertado, es el "+num4+"!");
                    }
                }

            }
    }
}
