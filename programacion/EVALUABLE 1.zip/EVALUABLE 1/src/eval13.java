import java.util.*;
public class eval13 {
    public static void main (String[]args){
        Scanner sc = new Scanner(System.in);

        int anyo=0;
        String nombre = "";
        int alturaini=0;
        int altura=0, subidas=0, bajadas=0;
        double media = 0.0f;
        int cont1=0, cont2=0, cont3=0;

        System.out.println("Introduza el año de fabricación del avión: ");
        anyo = sc.nextInt();
        sc.nextLine();
        System.out.println("Introduzca el nombre del avión: ");
        nombre = sc.nextLine();

        while (altura>=0) {
            System.out.println("Introduzca la nueva altura para " + nombre + ": ");
            altura = sc.nextInt();

            if (altura<=100){
                cont1++;
            }
            if ((altura>100)&&(altura<=200)){
                cont2++;
            }
            if ((altura>200)&&(altura<=300)){
                cont3++;
            }


            if (altura>alturaini){
                subidas=subidas+1;
            }else{
                bajadas=bajadas+1;
            }

            if (((altura - alturaini) == 1) || ((altura - alturaini) == -1)) {
                System.out.println("Lectura erronea! Solo le separa 1 metro de la última lectura");
            } else {
                alturaini = altura;
            }

            media = ((100*cont1)+(200*cont2)+(300*cont3))/(cont1+cont2+cont3);


            if (altura==-1){
                System.out.println("Subidas: "+subidas);
                System.out.println("Bajadas: "+bajadas);
                System.out.println("La altura media es "+media);
                break;
            }
        }
    }
}
